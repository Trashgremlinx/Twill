# Twill

**A Society of Fur toolkit for Wolvden.**

## What is Twill?

Twill reads the page you already have open, allows you to expand on details you otherwise would need a separate document to do and gives you space to grow your pack in a lore rich environment.

Hover over a gene and get expanded details on where it comes from, how it might look bred with another marking and if they can be a combo. Maybe you want to add more detail to your wolf that you simply don't have the ability to see at a glance without a separate lore document. Breeding challenges and planning your pack has become easier than ever.

**Twill will never play the game for you, we leave that to you!**

## A look at it

Hover a marking and you get its category, where it comes from, what it was bred from, and the
chance of passing it on:

    Deira Socks (65% : T6)
      Category     Combo marking, tier 6
      Source       Breeding only, never a Random Marking Applicator
      Bred from    Beige x Honey
      Pass rate    65% to a pup

Your den, summed up, with every section folding on its own and still answering itself when shut:

    v NEEDS ATTENTION                              5
      Anthelion                  pregnant, due in 3
      Styginetta                            in heat
      3 pups                    under 50% survival
      Elyos, Willow, OR1                 0% energy
    > BREEDING              3 in heat, 5 cooldowns
    > OLD AGE                             3 elders

Two wolves pinned in the tray, paired:

    Shared ancestors   Roustame Diodore, great-grandsire both sides
    The pup's COI      3.1%
    Markings in reach  Silver Dilution (slot 4), Beige Orca (slot 7)

And one search in the guides follows the whole chain out:

    "cough"  ->  Cough, -2 HP, 21% to spread each rollover
                 cured by Cough Cure
                 which needs Goldenseal, Kava, Pineapple Leaf
                 which grow in Deciduous Forest, Grasslands,
                 Coniferous Forest, Riparian Woodland, Rainforest

**Version 0.32.1.** One file, no dependencies, nothing downloaded, nothing sent anywhere.

---

## Install it, in two steps

**1. Install Tampermonkey.**
It is a free browser extension that runs userscripts. Get it from
[tampermonkey.net](https://www.tampermonkey.net/) and pick your browser. Chrome, Firefox,
Edge, Safari and Opera all work.

Chrome and Edge also need **Developer mode** switched on, or Tampermonkey will refuse to run
anything. Go to `chrome://extensions` (or `edge://extensions`) and flip the toggle in the corner.

**2. Click the install link.**
With Tampermonkey in place, this one link is the whole install:

**<https://trashgremlinx.github.io/Twill/twill.user.js>**

Tampermonkey catches it and shows you the script with an **Install** button. Press it.

Go to [wolvden.com](https://www.wolvden.com/). The **Twill** mark sits in the bottom right
corner of every page. Click it, or press `Alt+K`.

If the link opens as a wall of text instead, Tampermonkey did not catch it. Select all of it,
open the Tampermonkey dashboard, click the **+** tab, delete the starter script that appears,
paste, and save with `Ctrl+S`. The copy of `twill.user.js` beside this readme works the same way.

### Updating later

Nothing to do. Tampermonkey checks for a new version on its own and updates you, and everything
you have saved stays exactly where it is. Its dashboard has a **Check for userscript updates**
button if you are impatient.

---

## What it does

Open the hub with the corner button or `Alt+K`. The first thing it shows is a search box that
looks through everything at once, and your goals list. Everything else is one level down.

### On a wolf's page

| | |
|---|---|
| **Genetics** | Hover any gene for a card explaining it: what it is, where it comes from, what it pairs into, whether it is lethal. Click to pin the card open and scroll it. A coloured mark beside each gene says at a glance how that trait is obtained |
| **Lore** | Your own fields, in sections you name. Rename, reorder, add and delete them freely. Wolf-link fields cross-reference both ways, so if one wolf is bonded to another, both pages say so |
| **Collection** | Notes the base, eyes and markings of each wolf in your own pack as you open it, counted against the full catalogue |
| **Pedigree** | Keeps the family trees the pairing check needs, the last eight you opened |

### Across the site

| | |
|---|---|
| **Den Manager** | A card above your caves: care, breeding, pups, roles, old age, trades. Every section folds on its own, and any you never use can be switched off |
| **Tray** | Pin two wolves, then **Pair** them: what the pups could inherit slot by slot, and their shared ancestors. **Compare** puts any number side by side |
| **Wardrobe** | Custom decor as extra layers, which Wolvden's own list does not have. Save a look and wear it again. Each slot says what that decor is crafted from and whether you hold it |
| **Item Lookup** | A magnifier on any item: recipes, the catalogue, or the trading centre, already searched |
| **Shopping List** | Two lists you keep. Items you want are tagged **buy**, items you would trade away are tagged **in stock**, wherever they appear |
| **Store Front** | On Manage Your Trades: what to restock, and which trades have offers waiting |
| **Notepad** | A movable notepad on every page, `Alt+N`. Pictures by web address, and a note can be pinned to a wolf so it shows on their page |
| **Achievements** | Every category in one place, and unearned ones can be pushed onto your goals |
| **Hide users** | Collapses posts from players you would rather not read |

### Guides

Nine reference screens the game never puts anywhere you can read them, all built from the
Grouse House Wiki and kept offline:

**Herb map** · **Scout map** · **Pass rates** · **Illnesses** · **Food map** · **Pair bonds** ·
**Battle map** · **Befriending** · **Roles**

They are joined up rather than separate tables. Search `cough` in the herb map and it finds the
three herbs that cure it, because it reaches through the medicine to what it treats. The illness
list follows the same chain all the way out: illness, cure, herbs, and the biomes those herbs
grow in.

### Accessibility

Fishing colours are now given an upgrade for those with red-blind or green-blind colour vision, or those who may struggle to see the ripple during fishing. Twill does not point to the fish, but merely acts as a coloured pane put over the browser to add a little more contrast.

### Everywhere

**Eight themes** in beveled glass with a live editor, three of them (Tree Bark, Understory
and Frosted Cranberries) drawn from Twill's own colours and every swatch in every one of
them yours to change, a **post composer** that catches those pesky HTML breaks,
and **Backup** so you can carry everything with you to another computer.

Everything you save lives in your own browser. Nothing syncs between machines, so use Backup if
you move.

---

## What it will not do

Twill stays inside Wolvden's rules, deliberately and with no exceptions:

- It **never loads a page for you**. No randomly opened tabs.
- It **never clicks, submits or fills a form for you**. No auto-explore, bump tools or pre-chosen
  answers for battles and befriending.
- It **never refreshes** anything on a timer. You must manually bump all trade, raffles and chatter
  posts still.
- It **sends nothing anywhere**. There is no server, no account, no tracking, no analytics.
  Your notes and lore never leave your machine.

If you are ever unsure, the whole script is plain readable text. Read it.

---

## Questions

**Is this allowed? Will I get in trouble?**
Wolvden's rules forbid scripts that *play* the game: automation, auto-refreshers, anything that
clicks or submits for you. Twill does none of that. It reads a page you opened yourself and changes
how it looks, which is the same thing a custom den layout does. That said, the rules are written
broadly and staff are the ones who interpret them. Decide for yourself. Anything close to the line
has deliberately been left unbuilt, and the roadmap below names it.

**Does it send my data anywhere?**
No. No server, no account, no analytics, no external request of any kind. The script is plain
readable text, so you can check that yourself.

**The file is over half a megabyte. Will it slow the site down?**
No. Most of it is offline reference data: every base, eye colour, marking, mutation, recipe, herb,
prey item and battle enemy. Parsed once per page load. Keeping it in the file is what lets the
guides work without ever contacting the wiki.

**Do I have to use all of it?**
No. Every module has a switch under **Modules**. Switched off means never built, not merely hidden.

**What happens to my notes if I reinstall or update?**
Nothing. Everything is stored under keys that have never changed, even though the kit itself has
been renamed more than once. Moving computer? Use **Backup**, because browser storage does not follow you.

**Does it work on a phone?**
Only where userscripts do. Firefox on Android runs Tampermonkey; Safari on iOS needs an app such as
Userscripts. Panels do fold down, but this is built for a desktop browser first.

**Will it break when Wolvden changes a page?**
Possibly, and that is normal for any userscript. Worst case a panel stops appearing; the game itself
is never affected. Tell us in Discord and it gets fixed.

**Can I use it alongside other scripts?**
Usually. Uninstall any older copy of this one first, or you will get duplicates.

**Why does Chrome need Developer mode?**
A 2024 Chrome change means extensions cannot run userscripts without it. Tampermonkey's
requirement, not this script's, and it applies to every userscript.

**Is it free? Can I share it?**
Free, and yes. Pass it to anyone. Nothing in it is guild-locked.

---

## Future Journeys

Twill is not finished, and the thing we are most excited about is bigger than another module.

### A Society of Fur add-on, one day

An **opt-in add-on** that connects Twill to the Society of Fur: guild games, event boards, seasonal
challenges and whatever else we dream up together. Something that makes the guild feel present
while you play, rather than only in the forums.

**It would be a separate, opt-in piece, and Twill itself would not change.** The base kit stays
entirely local and sends nothing anywhere, exactly as it does now. Anything that talks to the
Society would be something you switch on knowingly, and it would say plainly what it sends before
you do.

If that sounds good, the best thing you can do is come and be part of it:
[join us on Discord](https://discord.gg/ZQDz8ANTUR).

---

## Thanks

**[The Grouse House Wiki](https://grousehouse.wiki/).** Every fact in the guides and the genetics
cards comes from there, written in Twill's own words. Thank you to the hardworking individuals who
have compiled all of the information there.

**Wolvden, by Lioden Ltd.** A big thanks to the developers of our beloved game, the hardworking
artists and the team members that make Wolvden what it is today. This is an unofficial fan tool and
is not affiliated with or endorsed by them.

**The Society of Fur members.** Thank you, community members, for sharing your thoughts, wishes and
general feedback during development. You've helped our little community grow into what it is today,
and this is us giving back to you.

By [Fallowe](https://www.wolvden.com/profile/145906)

---

## Come say hello

- **Discord:** https://discord.gg/ZQDz8ANTUR
- **Guild:** https://www.wolvden.com/g/society/991

Bugs, ideas and requests are all welcome.
